/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Views;


public class ViewProduct implements Factoryint{
    @Override
    public void making_new_page(){
        ProductUI productpage = new ProductUI();
        productpage.setVisible(true);
    }
    
}
