
package Views;

public class CreateSeller implements Factoryint{
    @Override
    public void making_new_page(){
        SellerUI sellerpage = new SellerUI();
        sellerpage.setVisible(true);
    }
    
}
