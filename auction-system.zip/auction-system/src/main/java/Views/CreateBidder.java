
package Views;


public class CreateBidder implements Factoryint {
    @Override
    public void making_new_page(){
        BidderUI bidderpage = new BidderUI();
        bidderpage.setVisible(true);
    }
   
    
}
