
package Views;


public class EnterAdmin implements Factoryint {
    @Override
    public void making_new_page(){
        AdminUI adminpage = new AdminUI();
        adminpage.setVisible(true);
    }
    
}
