
package Views;

/**
 *
 * @author Prajna
 */
public interface Factoryint {
    void making_new_page();
}
