
package Views;


public class AS {
    public static void main(String[] args) {
       Welcome page = new Welcome();
       page.setVisible(true);
    }
    
}
